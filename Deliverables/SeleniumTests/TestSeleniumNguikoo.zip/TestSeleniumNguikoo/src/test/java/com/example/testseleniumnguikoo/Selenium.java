package com.example.testseleniumnguikoo;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium {
    private static String result;

    @Test
    public static void main(String[] args){
        System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");

        WebDriver driver = new ChromeDriver();



        driver.get("https://www.calculator.net/scientific-calculator.html");
        driver.findElement(By.xpath("//*[@id=\"sciInPut\"]\n")).click();
        driver.findElement(By.xpath("//*[@id=\"sciout\"]/div[3]/div[3]/span[2]")).click();
        driver.findElement(By.xpath("//*[@id=\"sciout\"]/div[3]/div[2]/span[2]")).click();
        driver.findElement(By.xpath("//*[@id=\"sciout\"]/div[3]/div[1]/span[4]")).click();
        driver.findElement(By.xpath("//*[@id=\"sciout\"]/div[3]/div[3]/span[2]")).click();

        //driver.close();

        result = driver.findElement(By.xpath("//*[@id=\"sciOutPut\"]")).getText();

        TestSelenium.checkSum(" 27",result);

    }
}
