package com.example.testseleniumnguikoo;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestSelenium {
    public static void checkSum(String expected, String risultato){
        assertEquals(expected, risultato);
        System.out.println("la somma è: " +risultato);

    }
}
