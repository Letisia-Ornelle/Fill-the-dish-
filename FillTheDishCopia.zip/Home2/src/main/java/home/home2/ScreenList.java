package home.home2;

public class ScreenList {
/*
    public static String screen;

    public static void appendScreen(String source) {

    }

    public static ScreenList getPrev() {
        return ;
    }

    public static String getContent() {
        return;
    }
*/
}
