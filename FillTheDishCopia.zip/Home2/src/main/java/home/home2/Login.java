/*
package home.home2;

public class Login {
    public Boolean login(String user, String pwd) {

        if () {
            General.loginState = true;
            return true;
        } else {
            return false;
        }
    }
}
*/