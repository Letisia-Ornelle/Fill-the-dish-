package home.home2;

import javafx.event.ActionEvent;

import java.io.IOException;

public class Login2Controller {
    public void clickLogin(ActionEvent event) throws IOException {

    }

    public void clickRegister(ActionEvent event) throws IOException {

    }
}
