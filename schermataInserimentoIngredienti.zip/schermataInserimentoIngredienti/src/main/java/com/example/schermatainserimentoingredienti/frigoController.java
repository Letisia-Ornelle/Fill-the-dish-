package com.example.schermatainserimentoingredienti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class frigoController {
    @FXML
    Button backButton;
    @FXML
    Button homeButton;
    @FXML
    Button buttonricetta;
    public void screen(ActionEvent actionEvent) throws IOException {
        HelloApplication h = new HelloApplication();

        if (actionEvent.getSource() == backButton) {
            h.changeScene("hello-view.fxml");
        }
        if (actionEvent.getSource() == homeButton) {
            h.changeScene("hello-view.fxml");
        }
        if (actionEvent.getSource() == buttonricetta) {
            h.changeScene("ricettaOttenuta.fxml");
        }

    }
}
