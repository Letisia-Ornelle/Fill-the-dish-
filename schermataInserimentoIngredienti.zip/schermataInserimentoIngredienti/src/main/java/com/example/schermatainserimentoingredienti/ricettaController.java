package com.example.schermatainserimentoingredienti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class ricettaController {
    @FXML
    Button ricetta1;
    @FXML
    Button ricetta2;
    @FXML
    Button ricetta3;
    @FXML
    Button homeButton;
    @FXML
    Button backButton;
    @FXML
    Button bFridge;

    public void screen3(ActionEvent actionEvent) throws IOException {
        HelloApplication h = new HelloApplication();
        if (actionEvent.getSource() == ricetta1){
           h.changeScene("recipes3.fxml");
        }
        if (actionEvent.getSource() == backButton) {
            h.changeScene("hello-view.fxml");
        }
        if (actionEvent.getSource() == homeButton) {
            h.changeScene("hello-view.fxml");
        }

    }

}
