package com.example.schermatainserimentoingredienti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class HelloController {
   @FXML
   Button bFridge;
   @FXML
   Button buttonricetta;


    public void screen2(ActionEvent actionEvent) throws IOException {
        HelloApplication h = new HelloApplication();
        if(actionEvent.getSource()== bFridge){
            h.changeScene("ingredientiDalFrigo.fxml");
        }
        if(actionEvent.getSource()== buttonricetta){
            h.changeScene("ricettaOttenuta.fxml");
        }

    }
}