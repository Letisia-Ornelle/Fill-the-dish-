module com.example.schermatainserimentoingredienti {
    requires javafx.controls;
    requires javafx.fxml;




    opens com.example.schermatainserimentoingredienti to javafx.fxml;
    exports com.example.schermatainserimentoingredienti;
}